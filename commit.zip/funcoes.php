<?php
function conectar()
{
    $host = "localhost";
    $user = "root";
    $password = "";
    $banco = "crud_veiculos"; 

    $conect = mysqli_connect($host, $user, $password, $banco);
    if ($conect) {
        return $conect;
    } else {
        die("Problemas ao acessar o banco de dados. Erro: " . mysqli_connect_errno() . "" . mysqli_connect_error());
    }
}
if (isset($_POST['cadManu'])) {
    $veiculo = $_POST['veiculo'];
    $tipoServico = $_POST['tipo_servico'];
    $dataServico = $_POST['data_servico'];
    $descricaoServico = $_POST['descricao_servico'];
    $custoServico = $_POST['custo_servico'];

    $sql = "INSERT INTO manutencao (veiculo_id, tipo_servico, data_servico, descricao_servico, custo_servico) 
            VALUES ('$veiculo', '$tipoServico', '$dataServico', '$descricaoServico', '$custoServico')";
    mysqli_query(conectar(), $sql);
    header("location:telaVeiculo.php");
}
if (isset($_POST['editManu'])) {
    $id = $_POST['id'];
    $veiculo = $_POST['veiculo'];
    $tipoServico = $_POST['tipo_servico'];
    $dataServico = $_POST['data_servico'];
    $descricaoServico = $_POST['descricao_servico'];
    $custoServico = $_POST['custo_servico'];

    $sql = "UPDATE manutencao SET `veiculo_id`='$veiculo',`tipo_servico`='$tipoServico',`data_servico`='$dataServico',`descricao_servico`='$descricaoServico',`custo_servico`='$custoServico' 
            WHERE `id`='$id'";
    mysqli_query(conectar(), $sql);
    header("location:telaVeiculo.php");
}
if (isset($_GET['idExc'])) {
    $id = $_GET['idExc'];

    $sql = "DELETE FROM manutencao WHERE id=$id";
    mysqli_query(conectar(), $sql);
    header("Location:telaVeiculo.php");
}
?>
